import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain, Settings2, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface PomodoroProps {
  onComplete: (minutes: number) => void;
}

export default function Pomodoro({ onComplete }: PomodoroProps) {
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [customMinutes, setCustomMinutes] = useState(25);
  const [showSettings, setShowSettings] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    let interval: any = null;
    if (isActive) {
      interval = setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1);
        } else if (minutes > 0) {
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          handleComplete();
        }
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, minutes, seconds]);

  const handleComplete = () => {
    setIsActive(false);
    if (audioRef.current) {
      audioRef.current.play().catch(e => console.log('Audio play failed', e));
    }
    
    if (mode === 'focus') {
      onComplete(customMinutes);
      setMode('break');
      setMinutes(5);
    } else {
      setMode('focus');
      setMinutes(customMinutes);
    }
    setSeconds(0);
  };

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setMinutes(mode === 'focus' ? customMinutes : 5);
    setSeconds(0);
  };

  const progress = mode === 'focus' 
    ? ((customMinutes * 60 - (minutes * 60 + seconds)) / (customMinutes * 60)) * 100
    : ((5 * 60 - (minutes * 60 + seconds)) / (5 * 60)) * 100;

  return (
    <div className="card relative overflow-hidden">
      <audio ref={audioRef} src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3" />
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <div className={cn(
            "p-2 rounded-lg",
            mode === 'focus' ? "bg-primary/10 text-primary" : "bg-secondary/10 text-secondary"
          )}>
            {mode === 'focus' ? <Brain size={20} /> : <Coffee size={20} />}
          </div>
          <div>
            <h3 className="font-bold text-text-main">{mode === 'focus' ? 'Focus Mode' : 'Break Time'}</h3>
            <p className="text-[11px] text-text-sub uppercase font-bold tracking-wider">Study Timer Pro</p>
          </div>
        </div>
        <button 
          onClick={() => setShowSettings(!showSettings)}
          className="p-2 hover:bg-bg rounded-lg transition-colors text-text-sub"
        >
          <Settings2 size={18} />
        </button>
      </div>

      <div className="relative flex flex-col items-center justify-center py-8">
        {/* Progress Circle */}
        <svg className="w-48 h-48 -rotate-90">
          <circle
            cx="96"
            cy="96"
            r="88"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            className="text-border"
          />
          <motion.circle
            cx="96"
            cy="96"
            r="88"
            fill="none"
            stroke="currentColor"
            strokeWidth="8"
            strokeDasharray={553}
            initial={{ strokeDashoffset: 553 }}
            animate={{ strokeDashoffset: 553 - (553 * progress) / 100 }}
            className={mode === 'focus' ? "text-primary" : "text-secondary"}
            strokeLinecap="round"
          />
        </svg>

        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-5xl font-black text-text-main tabular-nums tracking-tighter">
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </span>
          <span className="text-[12px] font-bold text-text-sub uppercase mt-1">
            {mode === 'focus' ? 'Concentrate' : 'Relax'}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-center gap-4 mt-6">
        <button
          onClick={resetTimer}
          className="p-3 bg-bg hover:bg-border rounded-full transition-colors text-text-sub"
        >
          <RotateCcw size={20} />
        </button>
        <button
          onClick={toggleTimer}
          className={cn(
            "w-16 h-16 rounded-full flex items-center justify-center text-white shadow-lg transition-all hover:scale-105 active:scale-95",
            mode === 'focus' ? "bg-primary shadow-primary/30" : "bg-secondary shadow-secondary/30",
            isActive && "ring-4 ring-offset-2",
            mode === 'focus' ? "ring-primary/20" : "ring-secondary/20"
          )}
        >
          {isActive ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
        </button>
        <div className="w-11" /> {/* Spacer */}
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-6 pt-6 border-t border-border"
          >
            <label className="block text-[12px] font-bold text-text-sub uppercase mb-2">Custom Focus Time (min)</label>
            <div className="flex gap-2">
              {[15, 25, 45, 60].map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setCustomMinutes(m);
                    if (!isActive) setMinutes(m);
                  }}
                  className={cn(
                    "flex-1 py-2 rounded-lg text-[13px] font-bold transition-all border",
                    customMinutes === m 
                      ? "bg-primary text-white border-primary" 
                      : "bg-surface border-border text-text-sub hover:border-primary/30"
                  )}
                >
                  {m}m
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
