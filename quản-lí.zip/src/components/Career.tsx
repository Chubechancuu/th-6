import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Plus, 
  Trash2, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Mail, 
  Phone, 
  Globe, 
  MapPin,
  Sparkles,
  Layout,
  Eye,
  Type,
  Palette,
  CheckCircle2,
  AlertCircle,
  UserCircle,
  Edit3,
  ChevronDown,
  ChevronUp,
  Loader2,
  X,
  PlusCircle,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, CVData } from '../types';
import { cn } from '../lib/utils';
import { generateProjectDescription } from '../lib/gemini';

interface CareerProps {
  user: UserProfile;
}

export default function Career({ user }: CareerProps) {
  const [cvData, setCvData] = useState<CVData>({
    personalInfo: {
      fullName: user.name,
      email: '',
      phone: '',
      address: '',
      summary: `Sinh viên ${user.year} ngành Kinh tế với mục tiêu trở thành ${user.goal}. GPA hiện tại: ${user.gpa}.`
    },
    education: [
      { school: 'Trường Đại học Kinh tế', degree: 'Cử nhân', major: user.goal, startDate: '2022', endDate: '2026' }
    ],
    experience: [],
    skills: ['Microsoft Office', 'English'],
    projects: []
  });

  const [activeSection, setActiveSection] = useState<'edit' | 'preview'>('edit');
  const [isContactOpen, setIsContactOpen] = useState(true);
  const [isSkillsOpen, setIsSkillsOpen] = useState(true);
  const [showPrompt, setShowPrompt] = useState<{ type: 'experience' | 'skill' | 'project', title: string } | null>(null);
  const [promptValue, setPromptValue] = useState('');
  const [isGenerating, setIsGenerating] = useState<string | null>(null);

  const handleAddExperience = () => {
    if (promptValue.trim()) {
      setCvData({
        ...cvData,
        experience: [...cvData.experience, {
          company: promptValue,
          role: 'Thực tập sinh',
          period: '2024 - Hiện tại',
          desc: 'Mô tả công việc của bạn...'
        }]
      });
      setPromptValue('');
      setShowPrompt(null);
    }
  };

  const handleAddSkill = () => {
    if (promptValue.trim()) {
      setCvData({...cvData, skills: [...cvData.skills, promptValue]});
      setPromptValue('');
      setShowPrompt(null);
    }
  };

  const handleAddProject = () => {
    if (promptValue.trim()) {
      const newProject = {
        id: Math.random().toString(36).substr(2, 9),
        name: promptValue,
        desc: 'Mô tả dự án của bạn...',
        completed: false,
        skills: []
      };
      setCvData({
        ...cvData,
        projects: [...cvData.projects, newProject]
      });
      setPromptValue('');
      setShowPrompt(null);
    }
  };

  const handleGenerateDescription = async (projectId: string, projectName: string) => {
    setIsGenerating(projectId);
    try {
      const result = await generateProjectDescription(projectName, user.goal);
      setCvData(prev => ({
        ...prev,
        projects: prev.projects.map(p => p.id === projectId ? { ...p, desc: result.description } : p)
      }));
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(null);
    }
  };

  const handleAddProjectSkill = (projectId: string, skill: string) => {
    if (!skill.trim()) return;
    setCvData(prev => ({
      ...prev,
      projects: prev.projects.map(p => 
        p.id === projectId ? { ...p, skills: [...new Set([...p.skills, skill.trim()])] } : p
      )
    }));
  };

  const handleRemoveProjectSkill = (projectId: string, skillToRemove: string) => {
    setCvData(prev => ({
      ...prev,
      projects: prev.projects.map(p => 
        p.id === projectId ? { ...p, skills: p.skills.filter(s => s !== skillToRemove) } : p
      )
    }));
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-text-main tracking-tight">CV Builder Pro</h1>
          <p className="text-text-sub font-medium mt-1">Tạo CV chuyên nghiệp chuẩn ATS dành riêng cho sinh viên kinh tế.</p>
        </div>
        <div className="flex bg-surface p-1 rounded-xl border border-border">
          <button 
            onClick={() => setActiveSection('edit')}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-bold transition-all",
              activeSection === 'edit' ? "bg-primary text-white shadow-md" : "text-text-sub hover:text-text-main"
            )}
          >
            <Edit3 size={16} /> Chỉnh sửa
          </button>
          <button 
            onClick={() => setActiveSection('preview')}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-bold transition-all",
              activeSection === 'preview' ? "bg-primary text-white shadow-md" : "text-text-sub hover:text-text-main"
            )}
          >
            <Eye size={16} /> Xem trước
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Editor Sidebar */}
        <div className={cn(
          "lg:col-span-4 space-y-6",
          activeSection === 'preview' && "hidden lg:block"
        )}>
          <div className="card space-y-6">
            <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
              <UserCircle size={20} className="text-primary" /> Thông tin cá nhân
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Họ và tên</label>
                <input 
                  type="text" 
                  value={cvData.personalInfo.fullName}
                  onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, fullName: e.target.value}})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Email</label>
                  <input 
                    type="email" 
                    value={cvData.personalInfo.email}
                    onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, email: e.target.value}})}
                    className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Số điện thoại</label>
                  <input 
                    type="text" 
                    value={cvData.personalInfo.phone}
                    onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, phone: e.target.value}})}
                    className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Địa chỉ</label>
                <input 
                  type="text" 
                  value={cvData.personalInfo.address}
                  onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, address: e.target.value}})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                  placeholder="VD: Hà Nội, Việt Nam"
                />
              </div>
              <div>
                <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Tóm tắt mục tiêu</label>
                <textarea 
                  value={cvData.personalInfo.summary}
                  onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, summary: e.target.value}})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary h-24 resize-none"
                />
              </div>
            </div>
          </div>

          <div className="card space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                <Briefcase size={20} className="text-secondary" /> Kinh nghiệm
              </h3>
              <button 
                onClick={() => setShowPrompt({ type: 'experience', title: 'Nhập tên công ty/tổ chức' })}
                className="p-1.5 bg-secondary/10 text-secondary rounded-lg hover:bg-secondary/20 transition-all"
              >
                <Plus size={16} />
              </button>
            </div>
            {cvData.experience.length === 0 ? (
              <p className="text-[12px] text-text-sub italic text-center py-4">Chưa có kinh nghiệm nào được thêm.</p>
            ) : (
              <div className="space-y-3">
                {cvData.experience.map((exp, i) => (
                  <div key={i} className="p-3 bg-bg border border-border rounded-xl flex items-center justify-between group">
                    <div>
                      <p className="text-[13px] font-black text-text-main">{exp.company}</p>
                      <p className="text-[11px] text-text-sub font-bold">{exp.role}</p>
                    </div>
                    <button 
                      onClick={() => setCvData({...cvData, experience: cvData.experience.filter((_, index) => index !== i)})}
                      className="p-1.5 text-text-sub hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="card space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                <Palette size={20} className="text-accent" /> Kỹ năng
              </h3>
              <button 
                onClick={() => setShowPrompt({ type: 'skill', title: 'Nhập kỹ năng mới' })}
                className="p-1.5 bg-accent/10 text-accent rounded-lg hover:bg-accent/20 transition-all"
              >
                <Plus size={16} />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {cvData.skills.map((skill, i) => (
                <div key={i} className="px-3 py-1 bg-bg border border-border rounded-lg text-[12px] font-bold text-text-sub flex items-center gap-2">
                  {skill} 
                  <Trash2 
                    size={12} 
                    className="cursor-pointer hover:text-red-500" 
                    onClick={() => setCvData({...cvData, skills: cvData.skills.filter((_, index) => index !== i)})}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="card space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                <Target size={20} className="text-orange-500" /> Dự án
              </h3>
              <button 
                onClick={() => setShowPrompt({ type: 'project', title: 'Nhập tên dự án' })}
                className="p-1.5 bg-orange-500/10 text-orange-500 rounded-lg hover:bg-orange-500/20 transition-all"
              >
                <Plus size={16} />
              </button>
            </div>
            {cvData.projects.length === 0 ? (
              <p className="text-[12px] text-text-sub italic text-center py-4">Chưa có dự án nào được thêm.</p>
            ) : (
              <div className="space-y-6">
                {cvData.projects.map((project) => (
                  <div key={project.id} className="p-4 bg-bg border border-border rounded-xl space-y-4 relative group">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox"
                          checked={project.completed}
                          onChange={(e) => setCvData(prev => ({
                            ...prev,
                            projects: prev.projects.map(p => p.id === project.id ? { ...p, completed: e.target.checked } : p)
                          }))}
                          className="w-4 h-4 rounded border-border text-primary focus:ring-primary"
                        />
                        <input 
                          type="text"
                          value={project.name}
                          onChange={(e) => setCvData(prev => ({
                            ...prev,
                            projects: prev.projects.map(p => p.id === project.id ? { ...p, name: e.target.value } : p)
                          }))}
                          className="bg-transparent font-black text-[13px] text-text-main focus:outline-none border-b border-transparent focus:border-primary"
                        />
                      </div>
                      <button 
                        onClick={() => setCvData(prev => ({ ...prev, projects: prev.projects.filter(p => p.id !== project.id) }))}
                        className="p-1 text-text-sub hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>

                    <div className="relative">
                      <textarea 
                        value={project.desc}
                        onChange={(e) => setCvData(prev => ({
                          ...prev,
                          projects: prev.projects.map(p => p.id === project.id ? { ...p, desc: e.target.value } : p)
                        }))}
                        className="w-full bg-surface border border-border rounded-lg p-2 text-[12px] focus:outline-none focus:border-primary h-20 resize-none"
                        placeholder="Mô tả dự án..."
                      />
                      <button 
                        onClick={() => handleGenerateDescription(project.id, project.name)}
                        disabled={isGenerating === project.id}
                        className="absolute bottom-2 right-2 p-1.5 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-all disabled:opacity-50"
                        title="Gợi ý bằng AI"
                      >
                        {isGenerating === project.id ? <Loader2 className="animate-spin" size={14} /> : <Sparkles size={14} />}
                      </button>
                    </div>

                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-1.5">
                        {project.skills.map((skill, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-primary/5 text-primary text-[10px] font-bold rounded-md flex items-center gap-1">
                            {skill}
                            <X 
                              size={10} 
                              className="cursor-pointer hover:text-red-500" 
                              onClick={() => handleRemoveProjectSkill(project.id, skill)}
                            />
                          </span>
                        ))}
                      </div>
                      <input 
                        type="text"
                        placeholder="Thêm kỹ năng dự án..."
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleAddProjectSkill(project.id, (e.target as HTMLInputElement).value);
                            (e.target as HTMLInputElement).value = '';
                          }
                        }}
                        className="w-full bg-surface border border-border rounded-lg px-2 py-1 text-[11px] focus:outline-none focus:border-primary"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Preview Area */}
        <div className={cn(
          "lg:col-span-8",
          activeSection === 'edit' && "hidden lg:block"
        )}>
          <div className="sticky top-24">
            <div className="flex items-center justify-between mb-4 px-4">
              <div className="flex items-center gap-2 text-[12px] font-bold text-text-sub uppercase tracking-widest">
                <Layout size={16} /> Professional Template
              </div>
              <button 
                onClick={() => {}}
                className="flex items-center gap-2 px-6 py-2.5 bg-text-main text-white rounded-xl text-[14px] font-black hover:bg-black transition-all shadow-lg shadow-text-main/20"
                title="Sử dụng Ctrl+P để in trang web"
              >
                <Download size={18} /> Tải xuống PDF
              </button>
            </div>

            {/* CV Document */}
            <div className="bg-white shadow-2xl rounded-[2px] min-h-[1000px] w-full max-w-[800px] mx-auto overflow-hidden flex flex-col md:flex-row text-[#334155]">
              {/* Left Column */}
              <div className="w-full md:w-[280px] bg-[#F1F5F9] p-10 space-y-10">
                <div className="space-y-4">
                  <div className="w-32 h-32 bg-slate-300 rounded-full mx-auto overflow-hidden border-4 border-white shadow-sm">
                    <img src={`https://picsum.photos/seed/${user.name}/200/200`} alt="Avatar" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </div>
                  <div className="text-center">
                    <h2 className="text-xl font-black text-slate-900 leading-tight">{cvData.personalInfo.fullName}</h2>
                    <p className="text-[13px] font-bold text-primary uppercase tracking-wider mt-1">{user.goal}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <button 
                    onClick={() => setIsContactOpen(!isContactOpen)}
                    className="w-full flex items-center justify-between text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-200 pb-2 group hover:text-primary transition-colors"
                  >
                    <span>Liên hệ</span>
                    <div className="text-slate-300 group-hover:text-primary transition-colors">
                      {isContactOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    </div>
                  </button>
                  <AnimatePresence initial={false}>
                    {isContactOpen && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-3 overflow-hidden"
                      >
                        <div className="flex items-center gap-3 text-[12px] font-medium">
                          <Mail size={14} className="text-primary shrink-0" /> 
                          <span className="truncate">{cvData.personalInfo.email || 'email@example.com'}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[12px] font-medium">
                          <Phone size={14} className="text-primary shrink-0" /> 
                          <span>{cvData.personalInfo.phone || '0123 456 789'}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[12px] font-medium">
                          <MapPin size={14} className="text-primary shrink-0" /> 
                          <span className="truncate">{cvData.personalInfo.address || 'Hà Nội, Việt Nam'}</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="space-y-6">
                  <button 
                    onClick={() => setIsSkillsOpen(!isSkillsOpen)}
                    className="w-full flex items-center justify-between text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-200 pb-2 group hover:text-primary transition-colors"
                  >
                    <span>Kỹ năng</span>
                    <div className="text-slate-300 group-hover:text-primary transition-colors">
                      {isSkillsOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    </div>
                  </button>
                  <AnimatePresence initial={false}>
                    {isSkillsOpen && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-4 overflow-hidden"
                      >
                        {cvData.skills.length > 0 ? (
                          cvData.skills.map((skill, i) => (
                            <div key={i} className="space-y-1.5">
                              <div className="flex justify-between text-[11px] font-bold">
                                <span>{skill}</span>
                                <span>80%</span>
                              </div>
                              <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
                                <div className="h-full bg-primary w-[80%]" />
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-[11px] text-slate-400 italic">Chưa có kỹ năng nào.</p>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-200 pb-2">Ngoại ngữ</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[12px] font-bold">
                      <span>Tiếng Anh</span>
                      <span className="text-primary">IELTS 7.5</span>
                    </div>
                    <div className="flex justify-between text-[12px] font-bold">
                      <span>Tiếng Việt</span>
                      <span className="text-primary">Bản ngữ</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div className="flex-1 p-12 space-y-12 bg-white">
                <section className="space-y-4">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Giới thiệu
                  </h3>
                  <p className="text-[14px] leading-relaxed text-slate-600 font-medium">
                    {cvData.personalInfo.summary}
                  </p>
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Học vấn
                  </h3>
                  <div className="space-y-6">
                    {cvData.education.map((edu, i) => (
                      <div key={i} className="relative pl-6 border-l-2 border-slate-100">
                        <div className="absolute -left-[9px] top-0 w-4 h-4 bg-white border-2 border-primary rounded-full" />
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-black text-slate-900 text-[15px]">{edu.school}</h4>
                          <span className="text-[11px] font-bold text-slate-400">{edu.startDate} - {edu.endDate}</span>
                        </div>
                        <p className="text-[13px] font-bold text-primary">{edu.degree} - {edu.major}</p>
                        <p className="text-[12px] text-slate-500 mt-2 font-medium">GPA: {user.gpa}/4.0</p>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Kinh nghiệm
                  </h3>
                  {cvData.experience.length === 0 ? (
                    <div className="p-8 border-2 border-dashed border-slate-100 rounded-2xl text-center">
                      <p className="text-[13px] text-slate-400 font-medium">Hãy thêm kinh nghiệm làm việc hoặc hoạt động ngoại khóa để làm nổi bật CV của bạn.</p>
                    </div>
                  ) : (
                    <div className="space-y-8">
                      {cvData.experience.map((exp, i) => (
                        <div key={i} className="relative pl-6 border-l-2 border-slate-100">
                          <div className="absolute -left-[9px] top-0 w-4 h-4 bg-white border-2 border-secondary rounded-full" />
                          <div className="flex justify-between items-start mb-1">
                            <h4 className="font-black text-slate-900 text-[15px]">{exp.company}</h4>
                            <span className="text-[11px] font-bold text-slate-400">{exp.period}</span>
                          </div>
                          <p className="text-[13px] font-bold text-secondary">{exp.role}</p>
                          <p className="text-[12px] text-slate-500 mt-2 font-medium leading-relaxed">{exp.desc}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Dự án
                  </h3>
                  {cvData.projects.length === 0 ? (
                    <div className="p-8 border-2 border-dashed border-slate-100 rounded-2xl text-center">
                      <p className="text-[13px] text-slate-400 font-medium">Thêm các dự án cá nhân hoặc nhóm để thể hiện kỹ năng thực tế của bạn.</p>
                    </div>
                  ) : (
                    <div className="space-y-8">
                      {cvData.projects.map((project) => (
                        <div key={project.id} className="relative pl-6 border-l-2 border-slate-100">
                          <div className={cn(
                            "absolute -left-[9px] top-0 w-4 h-4 bg-white border-2 rounded-full",
                            project.completed ? "border-green-500" : "border-orange-500"
                          )} />
                          <div className="flex justify-between items-start mb-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-black text-slate-900 text-[15px]">{project.name}</h4>
                              {project.completed && (
                                <span className="px-1.5 py-0.5 bg-green-100 text-green-600 text-[9px] font-black uppercase rounded">Hoàn thành</span>
                              )}
                            </div>
                          </div>
                          <p className="text-[12px] text-slate-500 mt-2 font-medium leading-relaxed">{project.desc}</p>
                          {project.skills.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-3">
                              {project.skills.map((skill, idx) => (
                                <span key={idx} className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                                  #{skill}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Giải thưởng
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
                      <Award className="text-accent shrink-0" size={20} />
                      <div>
                        <h4 className="text-[13px] font-black text-slate-900">Sinh viên 5 tốt cấp Trường</h4>
                        <p className="text-[11px] text-slate-500 font-bold">Năm học 2023 - 2024</p>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Custom Prompt Modal */}
      <AnimatePresence>
        {showPrompt && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-surface rounded-[24px] p-8 w-full max-w-md border border-border shadow-2xl"
            >
              <h2 className="text-xl font-black text-text-main mb-6">{showPrompt.title}</h2>
              <input 
                type="text" 
                autoFocus
                value={promptValue}
                onChange={(e) => setPromptValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    if (showPrompt.type === 'experience') handleAddExperience();
                    else if (showPrompt.type === 'skill') handleAddSkill();
                    else if (showPrompt.type === 'project') handleAddProject();
                  }
                }}
                className="w-full bg-bg border border-border rounded-xl px-4 py-3 text-[14px] focus:outline-none focus:border-primary font-bold mb-6"
                placeholder="Nhập thông tin..."
              />
              <div className="flex gap-3">
                <button 
                  onClick={() => {
                    setShowPrompt(null);
                    setPromptValue('');
                  }}
                  className="flex-1 py-3 rounded-xl font-bold text-text-sub hover:bg-bg transition-colors"
                >
                  Hủy
                </button>
                <button 
                  onClick={() => {
                    if (showPrompt.type === 'experience') handleAddExperience();
                    else if (showPrompt.type === 'skill') handleAddSkill();
                    else if (showPrompt.type === 'project') handleAddProject();
                  }}
                  className="flex-1 py-3 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
                >
                  Thêm
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

